﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EmpTable.Models;

namespace EmpTable.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Student
            IList<Employee> employeeList = new List<Employee>{
                            new Employee() { Emp_id = 1, Name = "John", Age = 18 } ,
                            new Employee() { Emp_id = 2, Name = "Steve",  Age = 21 } ,
                            new Employee() { Emp_id = 3, Name = "Bill",  Age = 25 } ,
                            new Employee() { Emp_id = 4, Name = "Ram" , Age = 20 } ,
                            new Employee() { Emp_id = 5, Name = "Ron" , Age = 31 } ,
                            new Employee() { Emp_id = 4, Name = "Chris" , Age = 17 } ,
                            new Employee() { Emp_id = 4, Name = "Rob" , Age = 19 }
                        };
            // Get the students from the database in the real application

            public ActionResult Index()
            {
                return View(employeeList);
            }

            public ActionResult Edit(int Id)
            {
                //Get the employee from employeeList
                //Get the employee from the database in the real application
                var emp = employeeList.Where(s => s.Emp_id == Id).FirstOrDefault();

                return View(emp);
            }

        [HttpPost]
        public ActionResult Edit(Employee std)
        {
            //write code to update student 

            return RedirectToAction("Index");
        }

        public ActionResult Edit(int id, string name)
        {
            // do something here

            return View();
        }

        [HttpPost]
        public ActionResult Edit1(Employee id)
        {
            var idd = id.Emp_id;
            var name = id.Name;
            var age = id.Age;
            var standardName = id.standard.StandardName;

            //update database here..

            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Editt([Bind(Include = "Emp_Id, Name")] Employee id)
        {
            var name = id.Name;

            //write code to update student 

            return RedirectToAction("Index");
        }
    }
}