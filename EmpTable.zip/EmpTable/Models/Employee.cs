﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmpTable.Models
{
    public class Employee
    {
        public int Emp_id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public Standard standard { get; set; }
    }

    public class Standard
    {
        public int StandardId { get; set; }
        public string StandardName { get; set; }
    }

}